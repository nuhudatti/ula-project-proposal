import pytesseract
import cv2
import csv
import re
import os
from datetime import datetime

# Configure Tesseract OCR path (adjust if needed)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Predefined categories
CATEGORY_MAP = {
    "tooth": "Personal Care", "paste": "Personal Care", "soap": "Personal Care",
    "detergent": "Cleaning", "omo": "Cleaning", "colgate": "Personal Care",
    "sunlight": "Cleaning", "indomie": "Food", "noodle": "Food", "maggie": "Food",
    "rice": "Food", "milk": "Beverage", "sugar": "Food", "bread": "Food",
    "mayonnaise": "Food", "oil": "Food", "pack": "General", "cream": "Personal Care",
    "shampoo": "Personal Care", "brush": "Personal Care", "chocolate": "Snack",
    "stew": "Food", "meat": "Food", "fish": "Food", "lorem": "Food",
    "ipsum": "Food", "dolor sit amet": "Food", "consectetur": "Snack", "adipiscing elit": "Snack"
}

class Receipt:
    def __init__(self, filename):
        self.filename = filename
        self.items = []

    def load_image(self):
        image = cv2.imread(self.filename)
        if image is None:
            raise FileNotFoundError(f"❌ Could not read image: {self.filename}")
        return image

    def extract_text(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        return pytesseract.image_to_string(gray)

    def parse_items(self, text):
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        for line in lines:
            if any(word in line.lower() for word in ['total', 'cash', 'change', 'receipt']):
                continue

            match = re.search(r'(.+?)\s+([₦N]?\s?[\d.,]+)[\)]?$', line)
            if match:
                item_name = match.group(1).strip()
                price_str = match.group(2).replace('₦', '').replace('N', '').replace(',', '.').strip()
                try:
                    price = round(float(price_str))
                    category = self.categorize(item_name)
                    self.items.append((item_name, price, category))
                except:
                    continue

    def categorize(self, item_name):
        item_name = item_name.lower()
        for keyword, category in CATEGORY_MAP.items():
            if keyword in item_name:
                return category
        return "Uncategorized"

class ReceiptManager:
    def __init__(self):
        self.receipts = []
        self.output_file = "expenses.csv"

    def add_receipt(self, filename):
        if os.path.isfile(filename):
            self.receipts.append(filename)
            print(f"✅ Receipt added: {filename}")
        else:
            print("❌ File not found.")

    def process_receipts(self):
        if not self.receipts:
            print("⚠️ No receipts added yet.")
            return

        file_exists = os.path.isfile(self.output_file)
        with open(self.output_file, 'a', newline='') as file:
            writer = csv.writer(file)
            if not file_exists:
                writer.writerow(['Receipt', 'Item', 'Price', 'Category', 'Date'])

            for filename in self.receipts:
                try:
                    receipt = Receipt(filename)
                    img = receipt.load_image()
                    text = receipt.extract_text(img)
                    receipt.parse_items(text)

                    now = datetime.now().strftime("%Y-%m-%d %H:%M")
                    for item_name, price, category in receipt.items:
                        writer.writerow([filename, item_name, price, category, now])

                    print(f"✅ Processed: {filename}")
                except FileNotFoundError as e:
                    print(e)

        self.receipts.clear()
        print("📁 All receipts processed. Check 'expenses.csv' for your report.")

    def run(self):
        print("🔹 PYTHON RECEIPT MANAGER 🔹")
        print("🔁 Developed by Nuhu @ NITDA/NCAIR\n")

        while True:
            print("\nChoose an option:")
            print("1. Add receipt image")
            print("2. Process and generate report")
            print("3. Exit")

            choice = input("Enter your choice (1/2/3): ").strip()

            if choice == '1':
                img_name = input("🖼 Enter image file name (e.g., receipt1.jpg): ").strip()
                self.add_receipt(img_name)

            elif choice == '2':
                self.process_receipts()

            elif choice == '3':
                print("👋 Exiting. Goodbye!")
                break

            else:
                print("❌ Invalid choice. Please enter 1, 2, or 3.")

# Run the program
if __name__ == "__main__":
    manager = ReceiptManager()
    manager.run()
