import tkinter as tk
from tkinter import filedialog, messagebox
import os
import pytesseract
import cv2
import csv
from datetime import datetime
from dashboard import ExpenseDataLoader, ExpenseDashboard  # From your dashboard.py

# Set up OCR path
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

class ReceiptApp:
    def __init__(self, master):
        self.master = master
        master.title("🧾 Receipt Analyzer - Group 5")
        master.geometry("400x300")

        self.label = tk.Label(master, text="Smart Receipt Analyzer", font=("Arial", 14))
        self.label.pack(pady=10)

        self.upload_button = tk.Button(master, text="📁 Upload Receipt", command=self.upload_image)
        self.upload_button.pack(pady=5)

        self.process_button = tk.Button(master, text="⚙️ Process Receipt", command=self.process_receipt)
        self.process_button.pack(pady=5)

        self.dashboard_button = tk.Button(master, text="📊 Show Dashboard", command=self.show_dashboard)
        self.dashboard_button.pack(pady=5)

        self.status_label = tk.Label(master, text="", fg="green")
        self.status_label.pack(pady=10)

        self.receipt_file = ""

    def upload_image(self):
        self.receipt_file = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
        if self.receipt_file:
            self.status_label.config(text=f"Selected: {os.path.basename(self.receipt_file)}")

    def process_receipt(self):
        if not self.receipt_file:
            messagebox.showwarning("No File", "Please upload a receipt image first.")
            return

        img = cv2.imread(self.receipt_file)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        text = pytesseract.image_to_string(gray)

        with open("expenses.csv", 'a', newline='') as file:
            writer = csv.writer(file)
            if os.stat("expenses.csv").st_size == 0:
                writer.writerow(['Receipt', 'Item', 'Price', 'Category', 'Date'])

            lines = [line.strip() for line in text.split('\n') if line.strip()]
            for line in lines:
                if any(word in line.lower() for word in ['total', 'change']):
                    continue
                parts = line.rsplit(' ', 1)
                if len(parts) == 2:
                    item, price = parts
                    try:
                        amount = float(price.replace("₦", "").replace(",", "").strip())
                        category = "Uncategorized"
                        now = datetime.now().strftime("%Y-%m-%d %H:%M")
                        writer.writerow([self.receipt_file, item.strip(), amount, category, now])
                    except:
                        continue

        messagebox.showinfo("Done", "Receipt processed and saved.")
        self.status_label.config(text="✅ Receipt saved.")

    def show_dashboard(self):
        loader = ExpenseDataLoader()
        totals = loader.load_data()
        if totals:
            dashboard = ExpenseDashboard(totals)
            dashboard.show_bar_chart()
        else:
            messagebox.showinfo("No Data", "No data to display.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ReceiptApp(root)
    root.mainloop()
