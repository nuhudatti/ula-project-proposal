import pytesseract
import cv2
import csv
import re
import os
from datetime import datetime

# Setup OCR path
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Category mapping
category_map = {
    "tooth": "Personal Care",
    "paste": "Personal Care",
    "soap": "Personal Care",
    "detergent": "Cleaning",
    "omo": "Cleaning",
    "colgate": "Personal Care",
    "sunlight": "Cleaning",
    "indomie": "Food",
    "noodle": "Food",
    "maggie": "Food",
    "rice": "Food",
    "milk": "Beverage",
    "sugar": "Food",
    "bread": "Food",
    "mayonnaise": "Food",
    "oil": "Food",
    "pack": "General",
    "cream": "Personal Care",
    "shampoo": "Personal Care",
    "brush": "Personal Care",
    "chocolate": "Snack",
    "stew": "Food",
    "meat": "Food",
    "fish": "Food",
    "lorem": "Food",
    "ipsum": "Food",
    "dolor sit amet": "Food",
    "consectetur" : "Snack",
    "adipiscing elit" : "Snack"
}


def categorize(item_name):
    item_name = item_name.lower()
    for keyword, category in category_map.items():
        if keyword in item_name:
            return category
    return "Uncategorized"

# Store receipts user adds
receipt_list = []

def process_receipts(receipt_list):
    if not receipt_list:
        print("⚠️ No receipts added yet.")
        return

    csv_file = 'expenses.csv'
    file_exists = os.path.isfile(csv_file)

    with open(csv_file, 'a', newline='') as file:
        writer = csv.writer(file)

        if not file_exists:
            writer.writerow(['Receipt', 'Item', 'Price', 'Category', 'Date'])

        for filename in receipt_list:
            if not os.path.isfile(filename):
                print(f"❌ File not found: {filename}")
                continue

            print(f"\n📄 Processing: {filename}")
            img = cv2.imread(filename)
            if img is None:
                print(f"❌ Could not read {filename}")
                continue

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            raw_text = pytesseract.image_to_string(gray)

            lines = [line.strip() for line in raw_text.split('\n') if line.strip()]
            found = False

            for line in lines:
                if any(w in line.lower() for w in ['total', 'cash', 'change', 'receipt']):
                    continue

                match = re.search(r'(.+?)\s+([₦N]?\s?[\d.,]+)[\)]?$', line)
                if match:
                    item = match.group(1).strip()
                    price_str = match.group(2).replace('₦', '').replace('N', '').replace(',', '.').strip()

                    try:
                        price = round(float(price_str))
                        category = categorize(item)
                        now = datetime.now().strftime("%Y-%m-%d %H:%M")
                        writer.writerow([filename, item, price, category, now])
                        found = True
                    except:
                        continue

            if found:
                print(f"✅ {filename} processed.")
            else:
                print(f"⚠️ No valid items found in {filename}.")

def main():
    print("🔹 PYTHON RECEIPT MANAGER 🔹")
    print("🔁 Designed by Nuhu @ NITDA/NCIAIR\n")

    while True:
        print("\nChoose an option:")
        print("1. Add receipt image")
        print("2. Process and generate report")
        print("3. Exit")

        choice = input("Enter your choice (1/2/3): ").strip()

        if choice == '1':
            img_name = input("🖼 Enter image file name (e.g., receipt1.jpg): ").strip()
            if os.path.isfile(img_name):
                receipt_list.append(img_name)
                print(f"✅ Added: {img_name}")
            else:
                print("❌ File not found.")
        
        elif choice == '2':
            process_receipts(receipt_list)
            receipt_list.clear()  # optional: clear after processing
            print("📁 All receipts processed.\nCheck 'expenses.csv' for results.")
        
        elif choice == '3':
            print("👋 Exiting. Goodbye!")
            break
        else:
            print("❌ Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()
