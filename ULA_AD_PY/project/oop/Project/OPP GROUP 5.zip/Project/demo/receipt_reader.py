import pytesseract
import cv2
import csv
import re
from PIL import Image

# Set the path to Tesseract OCR (adjust if needed)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# === PHASE 1: Load image and extract raw text ===

# Load your receipt image
# img = cv2.imread('receipt.jpg')  # make sure your image is named 'receipt.jpg' or change this

# Ask user to enter the image file name
image_path = input("📸 Enter receipt image name (e.g., receipt.jpg): ").strip()

# Read the image from the given file
img = cv2.imread(image_path)

# Check if image is loaded
if img is None:
    print(f"❌ Error: Could not load image '{image_path}'. Please make sure the file exists.")
    exit()


# Convert image to grayscale (better for OCR accuracy)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Extract raw text using OCR
raw_text = pytesseract.image_to_string(gray)

# Clean and split into lines
lines = raw_text.split('\n')
lines = [line.strip() for line in lines if line.strip() != '']

# Show the cleaned lines
print("Cleaned Lines:")
for line in lines:
    print(f"-> {line}")

# === PHASE 2: Extract item names and prices ===

expenses = []

# Category keyword dictionary
category_map = {
    "tooth": "Personal Care",
    "paste": "Personal Care",
    "soap": "Personal Care",
    "detergent": "Cleaning",
    "omo": "Cleaning",
    "colgate": "Personal Care",
    "sunlight": "Cleaning",
    "indomie": "Food",
    "noodle": "Food",
    "maggie": "Food",
    "rice": "Food",
    "milk": "Beverage",
    "sugar": "Food",
    "bread": "Food",
    "mayonnaise": "Food",
    "oil": "Food",
    "pack": "General",
    "cream": "Personal Care",
    "shampoo": "Personal Care",
    "brush": "Personal Care",
    "chocolate": "Snack",
    "stew": "Food",
    "meat": "Food",
    "fish": "Food",
    "lorem": "Food",
    "ipsum": "Food",
    "dolor sit amet": "Food",
    "consectetur" : "Snack",
    "adipiscing elit" : "Snack"
}


for line in lines:
    line = line.strip()

    # Skip known irrelevant lines
    if any(word in line.lower() for word in ['total', 'cash', 'change', 'receipt', 'thank', 'approval', 'code']):
        continue

    # Match lines that end in a number (decimal, comma, or normal)
    match = re.search(r'(.+?)\s+([₦N]?\s?[\d.,]+)[\)]?$', line)

    if match:
        item = match.group(1).strip()
        price_str = match.group(2).strip()

        # Clean price string
        price_str = price_str.replace('₦', '').replace('N', '').replace(',', '.').strip()

        try:
            price = round(float(price_str))  # Use float() if you want decimal prices
            expenses.append({'item': item, 'price': price})
        except ValueError:
            continue

# Function to find category based on keywords
def categorize(item_name):
    item_name = item_name.lower()
    for keyword, category in category_map.items():
        if keyword in item_name:
            return category
    return "Uncategorized"

# Add category to each expense item
for e in expenses:
    e['category'] = categorize(e['item'])


# === Show the results ===

print("\nStructured Data with Categories:")
for e in expenses:
    print(f"{e['item']} - ₦{e['price']} - [{e['category']}]")


# === Save to CSV file ===

# with open('expenses.csv', 'w', newline='') as file:
#     writer = csv.writer(file)
#     writer.writerow(['Item', 'Price', 'Category'])
#     for e in expenses:
#         writer.writerow([e['item'], e['price'], e['category']])

import os

file_exists = os.path.isfile('expenses.csv')

with open('expenses.csv', 'a', newline='') as file:
    writer = csv.writer(file)

    # Write the header ONLY if the file is new
    if not file_exists:
        writer.writerow(['Item', 'Price', 'Category'])

    # Write all new rows
    for e in expenses:
        writer.writerow([e['item'], e['price'], e['category']])


