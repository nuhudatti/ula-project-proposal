import csv
from collections import defaultdict
import matplotlib.pyplot as plt


class ExpenseDataLoader:
    """
    📊 This class loads and organizes data from the expenses.csv file.
    """

    def __init__(self, csv_file='expenses.csv'):
        self.csv_file = csv_file
        self.category_totals = defaultdict(float)

    def load_data(self):
        """
        Reads the CSV and calculates the total price for each category.
        """
        try:
            with open(self.csv_file, 'r') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    category = row['Category']
                    price = float(row['Price'])
                    self.category_totals[category] += price
        except FileNotFoundError:
            print(f"❌ File not found: {self.csv_file}")
        except Exception as e:
            print(f"⚠️ Error reading file: {e}")

        return self.category_totals


class ExpenseDashboard:
    """
    📈 This class handles chart creation and display.
    """

    def __init__(self, category_totals):
        self.categories = list(category_totals.keys())
        self.totals = list(category_totals.values())

    def show_bar_chart(self):
        """
        Creates and shows a bar chart of expenses per category.
        """
        plt.figure(figsize=(10, 6))
        bars = plt.bar(self.categories, self.totals, color='skyblue')
        plt.title('Total Expenses by Category')
        plt.xlabel('Category')
        plt.ylabel('Total (₦)')
        plt.xticks(rotation=30)
        plt.grid(axis='y')

        # Add labels on top of each bar
        for bar in bars:
            yval = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2, yval + 5, f"₦{int(yval)}", ha='center', fontsize=9)

        plt.tight_layout()
        plt.show()


def main():
    print("📊 DASHBOARD VIEWER")
    print("🔁 Designed by Elona @ NITDA/NCAIR\n")

    # Step 1: Load data
    data_loader = ExpenseDataLoader()
    totals = data_loader.load_data()

    if totals:
        # Step 2: Create chart
        dashboard = ExpenseDashboard(totals)
        dashboard.show_bar_chart()
    else:
        print("⚠️ No data to display.")


if __name__ == "__main__":
    main()
