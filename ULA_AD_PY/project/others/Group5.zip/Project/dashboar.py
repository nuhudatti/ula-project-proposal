import csv
from collections import defaultdict
import matplotlib.pyplot as plt

# Step 1: Load categorized data from CSV
category_totals = defaultdict(float)

with open('expenses.csv', 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        category = row['Category']
        price = float(row['Price'])
        category_totals[category] += price

# Step 2: Prepare data for chart
categories = list(category_totals.keys())
totals = list(category_totals.values())

# Step 3: Create bar chart
plt.figure(figsize=(10, 6))
bars = plt.bar(categories, totals, color='skyblue')
plt.title('Total Expenses by Category')
plt.xlabel('Category')
plt.ylabel('Total (₦)')
plt.xticks(rotation=30)
plt.grid(axis='y')

# Step 4: Add price labels on bars
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval + 5, f"₦{int(yval)}", ha='center', fontsize=9)

# Show the chart
plt.tight_layout()
plt.show()
