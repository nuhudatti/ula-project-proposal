# Libraries need for the utils.py
import os # needed for interaction with the operating system for file and directory management
import random # generate random numbers
import string # provides useful constants for functions working with text
import time #to delay and stimulate loading


#data structures
user_data ={}

def password_generator(length: int=16 ) -> str:
    """
    Generates a strong password containing uppercase letters, lowercase letters, digits, and special characters.

    :param length: The desired length of the password (must be at least 16).
    :raises ValueError: If the length is less than 16 characters.
    :return: A randomly generated strong password.
    """
    if length < 16:
        raise ValueError("Password length must be at least 16 characters long.")

    lower = random.choice(string.ascii_lowercase) # select random lowercase letter
    upper = random.choice(string.ascii_uppercase) # select random uppercase letter
    digit = random.choice(string.digits) # selecting random digits
    special = random.choice(string.punctuation) # selecting random symbols

    remaining_length = length - 4 # to select randomly after 4 has been chosen already

    all_chars = string.digits + string.ascii_letters + string.punctuation
    rest = [random.choice(all_chars) for _ in range(remaining_length)] # generate a list of random characters
    # used the _ as a throwaway variable
    gen_password = list(upper + lower + digit + special + "".join(rest)) # Generated password by combining all the characters
    random.shuffle(gen_password)

    return "".join(gen_password)# convert list to a string and return the generated password

def confirm_password_strength(password: str) -> bool:
    """
    Checks whether a given password meets the strong password requirements.

    :param password: The password to evaluate.
    :return: True if the password is strong, otherwise False.
    """

    if len(password) < 16:
        return False
    # usage of if not condition for to logical independence
    if not any(char.islower() for char in password):
        return False
    if not any(char.isupper() for char in password):
        return False
    if not any(char.isdigit() for char in password):
        return False
    if not any(char in string.punctuation for char in password): return False

    return True # When it passes all the requirement

def clear_screen() -> None:
    """
      Clears the terminal screen.

      This function detects the operating system and runs the appropriate command:
      - 'cls' for Windows
      - 'clear' for Linux/macOS
      """
    os.system("cls" if os.name == "nt" else "clear")# to clear cluttered output on the command-Line

def pause() -> None:
    """

    :return: a string
    Pauses the program until the user presses Enter.

    Useful for allowing the user time to read output or break up screen flow
    in the command line
    """
    input("\nPress Enter to continue...")

def wait(seconds: int= 1) -> None:
    """
    Args:
        seconds (int, optional): Number of seconds to wait. Defaults to 1
    :return: None

    Pauses execution for the specified number
    """
    time.sleep(seconds)

def slow_print(text :str, delay: float = 0.03) :
    """
    Prints text character by character with a delay, creating a typing effect.

    :param text: The string to be printed.
    :param delay: (float, optional) Time delay between each character. Defaults to 0.03 seconds.
    :return: None

    """
    for char in text: # iterate through each character in the text
        print(char, end="", flush=True) # Print character without a newline, ensuring immediate output
        time.sleep(delay)
    print() # move to a new line after printing the full text

def loading(message :str = "Processing", dots: int= 3, delay: float=0.5) -> None:
    """
        Displays a loading message followed by animated dots.

        :param message: The text to display before the dots.
        :param dots: Number of dots to print.
        :param delay: Time interval between each dot.
        :return: None
        """

    print(message, end = "", flush = True)  # Print message without newline, ensuring immediate output
    for num_of_dot in range(dots):
        print(".", end = "", flush = True) # print dot without newline, ensuring immediate output
        time.sleep(delay)# pause before printing the next dot
    print() # Move to anew line after printing all the dot

""" Heba's Code starts from here """

def load_users(file):
    global user_data
    user_data.clear()
    if os.path.exists(file):
        with open(file,'r') as f:
            for line in f:
                if line.strip():
                    username, email, password , balance = line.strip().split(',')
                    user_data[username] = {
                        'email' : email,
                        'password' : password,
                        'balance': float(balance)
                    }
def save_users(file):
    """ This saves user data to account.txt"""
    with open(file, 'w') as f:
        for username, data in user_data.items():
            f.write(f"{username},{data['email']},{data['password']},{data['balance']}\n")





