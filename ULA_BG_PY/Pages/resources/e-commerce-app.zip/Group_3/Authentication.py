import os # needed for interaction with the operating system for file and directory management

# Importing functions from utils needed in authentication
from utils import(
    password_generator,
    confirm_password_strength,
    slow_print,
    loading,
    pause,
)

DATA_DIR = "data" # data is the name of our folder of the working directory
ACCOUNTS_FILE = os.path.join(DATA_DIR, "accounts.txt") # creates path to account.txt inside the data folder
current_user = None


def ensure_data_files() -> None:
    """
    Ensure the data directory and accounts.txt file exists.
    :return: None
    """

    os.makedirs(DATA_DIR, exist_ok= True) # Create the data directory if it doesn't exist
    if not os.path.exists(ACCOUNTS_FILE): # Check if the accounts.txt file exists; if not, create an empty file
        with open(ACCOUNTS_FILE, "w") as f: # the 'w' makes the file in write mode
            pass # creates an empty file without writing any content
            # note teh pass is a placeholder statement meaning do nothing

def sign_up() -> str|None:
    """
    Creates a new user account.
    :return: None
    """
    global current_user
    ensure_data_files()
    slow_print("---Welcome, Sign up with us today---\n")
    username = input("Enter a unique username: ").strip() # removes spaces before and after it
    email = input("Enter your email address: ").strip()

    # Check for duplicate username or email
    with open(ACCOUNTS_FILE, "r") as file:
        for line in file:
            if not line.strip():
                continue
            existing_username, existing_email, *_ =line.strip().split(",") #extract username and email from the line
            if username == existing_username or email == existing_email:
                slow_print(" Username or email already exits, Please try again")
                pause()
                return None

        # Password setup with validation and retry for invalid input
        while True:
            choice  = input("Do you want a auto generated password? (y/n): ").lower()
            if choice == 'y':
                password = password_generator()
                slow_print(f" Your generated password is: {password}.\nDo well to write it down" )
                break
            elif choice == 'n':
                password = input("Enter your password( Minimum of 16 char): ").strip()
                if not confirm_password_strength(password):
                    slow_print("Your password isn't strong enough")
                    pause()
                    return None
                break
            else:
                print("Invalid input. Please type 'yes' or 'no'. ")
                pause()


    # Save user details
    with open(ACCOUNTS_FILE, "a")as file:
        '''Space removed '''
        file.write(f"{username},{email},{password},0.00\n")

    loading("Creating your account")
    slow_print(" Account Created successfully!\n")
    pause()
    current_user = username
    return username

def sign_in () -> str|None:
    """
    Authenticates an existing user account.
    :return: None
    """
    global  current_user
    ensure_data_files()
    slow_print("Sign into your account\n")
    while True:
        input_id = input("Enter your username or email (or 'q' to cancel): ").strip()
        if input_id.lower() == 'q':
            return None

        password = input("Enter your password: ").strip()
        loading("Checking credentials")

        with open(ACCOUNTS_FILE, "r") as file:
            for line in file:
                if not line.strip():
                    continue
                username, email, saved_password, *_ = line.strip().split(",")
                if input_id == username or input_id == email:
                    if password == saved_password:
                        slow_print(f"Login successful. Welcome back, {username}!\n")
                        pause()
                        current_user =  username
                        return username
                    else:
                        slow_print("Incorrect password.")
                        pause()
                        break
            else:
                slow_print("No account found.")
                pause()




