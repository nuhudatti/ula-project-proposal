
import re
from utils import slow_print, pause, loading, clear_screen


def search_and_add_menu(inventory_instance) -> None:
    """
    Prompts the user to search for items and optionally add them to the cart.
    Uses case-insensitive regex matching with partial word search.

    :param inventory_instance: An instance of the Inventory class
    """
    while True:
        slow_print("\nSearch Inventory")
        query = input("Enter item name or brand to search: ").strip()
        if not query:
            slow_print("Search query cannot be empty.")
            pause()
            continue

        search_terms = query.split()
        regex_patterns = [re.compile(re.escape(term), re.IGNORECASE) for term in search_terms]

        matches = [
            item_name for item_name in inventory_instance.inventory
            if all(pattern.search(item_name) for pattern in regex_patterns)
        ]

        if not matches:
            slow_print("No matching items found.")
            pause()
            continue

        while True:
            # Re-display matched items
            slow_print("\nMatched Items:")
            print(f"{'No.':<4} {'Item Name':<40} {'Price':<25} {'Stock'}")
            print("-" * 80)
            for idx, item in enumerate(matches, 1):
                price = inventory_instance.inventory[item]
                stock = inventory_instance.stock.get(item, 0)
                print(f"{idx:<4} {item:<40} price: NGN {price:,.2f}      stock: {stock}")

            # Show action options
            print("\nOptions:")
            print("1. Add item to cart")
            print("2. Search again")
            print("3. Exit Search Menu")

            choice = input("Choose an option (1-3): ").strip()

            if choice == "1":
                try:
                    item_number = input("Enter item number to add: ").strip()
                    if not item_number.isdigit():
                        raise ValueError
                    idx = int(item_number) - 1
                    if idx < 0 or idx >= len(matches):
                        raise ValueError

                    item_name = matches[idx]
                    qty_input = input("Enter quantity to add: ").strip()
                    if not qty_input.isdigit() or int(qty_input) <= 0:
                        raise ValueError

                    qty = int(qty_input)
                    success = inventory_instance.add_to_cart(item_name, qty)
                    if success:
                        slow_print(f"Added {qty} x {item_name} to cart.")
                    else:
                        slow_print("Not enough stock available.")
                except ValueError:
                    slow_print("Invalid input.")
                pause()

            elif choice == "2":
                break  #break to return to search input

            elif choice == "3":
                return  #exit entire search menu

            else:
                slow_print("Invalid option.")
                pause()

def manage_cart(inventory_instance, username: str) -> None:
    """
        Displays the manage cart menu and performs cart operations using the inventory instance.

        :param inventory_instance: An instance of the Inventory class
        :param username: The currently logged-in user
        """
    while True:
        slow_print("\n=== Manage Cart ===")
        print("1. View Items in Cart")
        print("2. Search for item and Add to Cart")
        print("3. Browse and Add from full Inventory")
        print("4. Remove Items from Cart")
        print("5. Clear Cart")
        print("6. Proceed to Checkout")
        print("7. Exit Manage Cart")

        choice = input("Choose an option (1-6): ").strip()

        if choice == "1":
            slow_print(inventory_instance.view_cart())
            pause()

        elif choice == "2":
            search_and_add_menu(inventory_instance)

        elif choice == "3":

            items = list(inventory_instance.inventory.keys())

            slow_print("\n🛍️ Available Inventory:")

            for idx, item in enumerate(items, 1):
                price = inventory_instance.inventory[item]

                print(f"{idx}. {item} - NGN {price:,.2f}")

            # Early input validation for item selection

            selection_input = input("Enter the number of the item to add: ").strip()

            if not selection_input.isdigit():
                slow_print("Invalid input. Please enter a valid number from the list.")

                pause()

                continue

            selection = int(selection_input) - 1

            if selection < 0 or selection >= len(items):
                slow_print("Selected item is out of range.")

                pause()

                continue

            # Early input validation for quantity

            quantity_input = input("Enter quantity to add: ").strip()

            if not quantity_input.isdigit() or int(quantity_input) <= 0:
                slow_print("Invalid quantity. Please enter a positive number.")

                pause()

                continue

            qty = int(quantity_input)

            item_name = items[selection]

            inventory_instance.add_to_cart(item_name, qty)

            slow_print(f"Added {qty} x {item_name} to cart.")

            pause()


        elif choice == "4":
            if not inventory_instance.cart:
                slow_print("Your cart is empty. ")
                pause()
                continue

            cart_items = list(inventory_instance.cart.keys())
            slow_print("\nYour Cart:")
            for idx, item in enumerate(cart_items, 1):
                qty = inventory_instance.cart[item]
                print(f"{idx}. {item} (x{qty})")
            try:
                selection = int(input("Enter the number of the item to remove: ")) - 1
                if selection < 0 or selection >= len(cart_items):
                    raise ValueError
                qty = int(input("Enter quantity to remove: "))
                if qty <= 0:
                    raise ValueError
                item_name = cart_items[selection]
                inventory_instance.remove_from_cart(item_name, qty)
                slow_print(f"Removed {qty} x {item_name} from cart.")
            except ValueError:
                slow_print("Invalid input.")
            pause()

        elif choice == "5":
            confirm = input("Are you sure you want to clear your cart? (yes/no): ").lower()
            if confirm == "yes":
                inventory_instance.clear_cart()
                slow_print("Cart cleared.")
            else:
                slow_print("Cart clear cancelled.")
            pause()

        elif choice == "6":
            slow_print(inventory_instance.view_cart())
            confirm = input("Proceed to checkout? (yes/no): ").strip().lower()
            if confirm == "yes":
                success = inventory_instance.checkout(username)
                if success:
                    loading("Processing payment")
                    slow_print("Transaction successful! Thank you for your purchase.")
                else:
                    slow_print("Checkout failed. Insufficient funds or empty cart.")
                pause()
            else:
                slow_print("Checkout cancelled.")
                pause()

        elif choice == "7":
            break

        else:
            slow_print("Invalid choice.")
            pause()