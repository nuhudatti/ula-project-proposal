# EasyBuy Application (Python)

This is a Command-Line Interface (CLI) E-Commerce Application built with Python. It simulates a basic online shopping experience, enabling users to register, log in, search for items using flexible regular expressions, add them to a personal cart, and make purchases using account balances.

>  This project was built by group 3 members as part of the Python Beginners Cohort 25 at NCAIR.

---

##  Project Structure

```
.
├── main.py               # Main program logic and interface
├── Authentication.py     # Handles user login, registration, and verification
├── account.txt           # Stores user credentials and wallet balances
├── items.txt             # Inventory of all available products
├── cart/                 # Stores user-specific cart files
└── README.md             # Project documentation
```

---

##  Features

-  User Authentication: Secure login and registration using `account.txt`
-  Inventory Management: View and update item quantities from `items.txt`
-  Cart System: Add to/view personal cart saved in `/cart` directory
-  Account Balance: Simulates a user wallet with balance deduction on checkout
-  Regex-Based Search: Search items using flexible regular expressions
-  Python OOP: Organized using object-oriented principles

---

##  User Account System

account.txt format:

```
username,email,password,balance
```

Example:
```
user,user,Username123456789@,118800.00
```

- Passwords must be strong (minimum length and special characters).
- Balance is checked before purchases and updated after transactions.

---

## Items and Inventory

items.txt format:

```
item_name,item_id,price,quantity
```

Example:
```
milk,101,300.0,10
laptop,105,150000.0,2
pen,109,50.0,20
```

Inventory is automatically updated after purchase to reflect reduced stock.

---

##  Shopping Cart

- Each user has a personal cart stored as a `.txt` file inside `/cart/`
- Cart files track:
  - Item Name
  - ID
  - Unit Price
  - Quantity
  - Total per item
- Users can view cart contents before checking out
- On successful purchase:
  - User's balance in `account.txt` is updated
  - Inventory in `items.txt` is reduced
  - Cart is cleared

---

##  Regex-Based Item Search

This feature allows users to search for products using **flexible search patterns**:

- Partial words: `pen` → shows "pen", "pencil", etc.
- Case insensitive matching
- Item ID, name, or even category-like hints

After displaying matching results, users can:
- Add an item to the cart
- Search again
- Exit search mode

---

##  Sample Data

###  Users in `account.txt`

```
DxeterLord,dexter@gmail.com,Dexter1234TTTT@@@@@$$$$qqq,0.0
2,k,=#U0Nc~l{Uz'{.&[,10000.0
user,user,Username123456789@,118800.00
new,new,Usename12345689@,0.00
```

###  Items in `items.txt`

```
milk,101,300.0,10
book,103,150.0,5
laptop,105,150000.0,2
pen,109,50.0,20
```

---

##  How to Run the Project

### ️ Requirements

- Python 3.x
- OS: Windows, macOS, or Linux

###  Run the program

```bash
$ python main.py
```

###  Usage Flow

1. Register or log in
2. View available items or search using regex
3. Add item(s) to cart
4. View cart
5. Proceed to checkout if balance allows
6. Exit or continue shopping

---

##  Technologies Used

- Python 3
- Object-Oriented Programming (OOP)
- Regular Expressions (Regex)
- File I/O (Read, Write, Append)
- Terminal-based interaction

---

##  Lessons and Skills Demonstrated

-  File handling in Python
-  Using regex to perform flexible searches
-  Building CLI applications
-  Implementing basic authentication
-  Simulating shopping behavior (cart, balance deduction)
-  Team collaboration on real-world projects

---

##  Possible Future Improvements

-  Encrypt and hash passwords
-  Add transaction history for users
-  View inventory statistics
-  Migrate to GUI (Tkinter, PyQt)
-  Use database (SQLite or PostgreSQL) instead of flat files
-  Add REST API backend with Flask or FastAPI

---

##  Authors & Credits

Built by [Your Name] and Group Members  
**Python Beginners Cohort 25 Internship Project @ NCAIR**  
Mentored by [Mentor's Name, if any]

---

##  License

This project is for educational purposes and may be freely modified and reused with proper attribution.

---
