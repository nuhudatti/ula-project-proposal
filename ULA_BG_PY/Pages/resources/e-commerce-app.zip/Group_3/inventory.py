import os
import re
from typing import Dict, List
from utils import slow_print, loading, pause

# Constants
DATA_DIR = "data"
WAREHOUSE_FILES_PATTERN = "warehouse*.txt"

class Inventory:
    def __init__(self):
        """Initialize the inventory system."""
        self.inventory: Dict[str, float] = {}  # {item_name: price}
        self.stock: Dict[str, int] = {}  # {item_name: quantity}
        self.cart: Dict[str, int] = {}  # {item_name: quantity}
        self.load_inventory()

    def load_inventory(self) -> None:
        """
        Load inventory items from all warehouse files.
        Format: <NAME>:<PRICE>:<STOCK>, separated by semicolons.
        """
        self.inventory.clear()
        self.stock.clear()  # clear previous stock data

        os.makedirs(DATA_DIR, exist_ok=True)

        warehouse_files = [
            os.path.join(DATA_DIR, f)
            for f in os.listdir(DATA_DIR)
            if re.match(WAREHOUSE_FILES_PATTERN.replace("*", ".*"), f)
        ]

        if not warehouse_files:
            slow_print("Warning: No warehouse files found in data directory!")
            return

        for filepath in warehouse_files:
            try:
                with open(filepath, 'r') as file:
                    content = file.read().strip()
                    if not content:
                        continue

                    items = [item.strip() for item in content.split(';') if item.strip()]
                    for item in items:
                        try:
                            parts = item.split(':')
                            if len(parts) == 2:
                                name, price = parts
                                quantity = "20"
                            elif len(parts) == 3:
                                name, price, quantity = parts
                            else:
                                raise ValueError("Too many colons")

                            item_name = name.strip()
                            self.inventory[item_name] = float(price.strip())
                            self.stock[item_name] = int(quantity.strip())
                        except ValueError:
                            slow_print(f"Skipping malformed item in {filepath}: {item}")


            except IOError:
                continue

        if not self.inventory:
            slow_print("Warning: Inventory is empty!")
        else:
            slow_print(f"Loaded {len(self.inventory)} items from inventory.")

    def search_items(self, query: str) -> List[str]:
        """
        Search for items in inventory matching the query (case-insensitive, partial matches).
        
        Args:
            query: The search string entered by user
            
        Returns:
            List of matching item names
        """
        if not query.strip():
            return []
            
        search_terms = query.split()
        regex_patterns = [re.compile(re.escape(term), re.IGNORECASE) for term in search_terms]
        
        matches = []
        for item in self.inventory:
            if all(pattern.search(item) for pattern in regex_patterns):
                matches.append(item)
                
        return matches

    def add_to_cart(self, item_name: str, quantity: int = 1) -> bool:
        """
        Add an item to the shopping cart.
        
        Args:
            item_name: Name of item to add
            quantity: Quantity to add (default 1)
            
        Returns:
            True if successful, False if item not in inventory
        """
        if item_name not in self.inventory:
            return False

        available = self.stock.get(item_name, 0)
        if available < quantity:
            slow_print(f"Only {available} in stock.")
            return False

        self.stock[item_name] -= quantity
        self.cart[item_name] = self.cart.get(item_name, 0) + quantity
        return True

    def remove_from_cart(self, item_name: str, quantity: int = 1) -> bool:
        """
        Remove an item from the shopping cart.
        
        Args:
            item_name: Name of item to remove
            quantity: Quantity to remove (default 1)
            
        Returns:
            True if successful, False if item not in cart or quantity invalid
        """
        if item_name not in self.cart:
            return False

        current_quantity = self.cart[item_name]
        if quantity >= current_quantity:
            self.stock[item_name] += current_quantity
            del self.cart[item_name]
        else:
            self.cart[item_name] -= quantity
            self.stock[item_name] += quantity

        return True

    def clear_cart(self) -> None:
        """Clear all items from the shopping cart."""
        self.cart.clear()

    def get_cart_total(self) -> float:
        """
        Calculate the total cost of items in cart.
        
        Returns:
            Total cost as float
        """
        total = 0.0
        for item, quantity in self.cart.items():
            if item in self.inventory:
                total += self.inventory[item] * quantity
        return total

    def view_cart(self) -> str:
        """
        Generate a formatted string showing cart contents.
        
        Returns:
            Formatted string of cart items and total
        """
        if not self.cart:
            return "Your cart is empty."
            
        cart_str = "=== Your Shopping Cart ===\n"
        for item, quantity in self.cart.items():
            price = self.inventory.get(item, 0)
            cart_str += f"{item} x{quantity} @ NGN {price:,.2f} = NGN {price * quantity:,.2f}\n"
        
        cart_str += f"\nTotal: NGN {self.get_cart_total():,.2f}"
        return cart_str

    def checkout(self, username: str) -> bool:
        """
        Process checkout by deducting cart total from user's wallet.
        
        Args:
            username: Username of the customer
            
        Returns:
            True if checkout successful, False if insufficient funds
        """
        from wallet import deduct_wallet
        
        total = self.get_cart_total()
        if total <= 0:
            return False
            
        if deduct_wallet(username, total):
            self.clear_cart()
            return True
        return False