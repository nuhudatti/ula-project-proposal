from Authentication import sign_in, sign_up, ACCOUNTS_FILE
from inventory import Inventory
from cart import manage_cart
from wallet import fund_wallet
from Account import manage_account
from utils import clear_screen, slow_print, pause, load_users, user_data

def welcome_menu() -> str:
    """
    Displays the initial welcome menu and handles sign in or sign up.

    :return: Username of the authenticated user or None.
    """
    while True:
        clear_screen()
        slow_print("Welcome to EasyBuy!\n")
        print("1. Sign In")
        print("2. Sign Up")
        print("3. Exit")

        choice = input("Choose an option (1-3): ").strip()

        if choice == "1":
            user = sign_in()
            if user:
                return user
        elif choice == "2":
            user = sign_up()
            if user:
                return user
        elif choice == "3":
            slow_print("Goodbye!")
            exit()
        else:
            slow_print("Invalid choice.")
            pause()


def run_section(username) -> None:
    """
    Displays the post-login main menu for the user to access wallet, purchase, or account settings.

    :param username: The currently logged-in user.
    :return: None
    """
    # Reload user data to check existence
    load_users(ACCOUNTS_FILE)

    if username not in user_data:
        slow_print("⚠Your account no longer exists. Please sign in again or create a new account.")
        pause()
        return

    inventory = Inventory()  # Load inventory and initialize cart for user

    while True:
        clear_screen()
        slow_print(f"\nMain Menu — Logged in as: {username}\n")
        print("1. Fund Wallet")
        print("2. Purchase Items")
        print("3. Manage Account")
        print("4. Logout")

        choice = input("Choose an option (1-4): ").strip()

        if choice == "1":
            fund_wallet(username)

        elif choice == "2":
            manage_cart(inventory, username)

        elif choice == "3":  # Manage Account
            updated_user = manage_account(username)
            if updated_user != username:
                username = updated_user or None
                if username is None:
                    break


        elif choice == "4":
            slow_print("Logging out...")
            pause()
            break

        else:
            slow_print("invalid choice.")
            pause()


def main() -> None:
    """
    Starts the application and manages user session flow.
    """
    while True:
        user = welcome_menu()
        if user:
            run_section(user)


if __name__ == "__main__":
    main()