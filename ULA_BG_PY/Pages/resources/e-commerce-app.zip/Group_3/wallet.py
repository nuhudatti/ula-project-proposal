"""
wallet.py

This module handles wallet functionalities such as balance storage, wallet funding, transaction deduction,
balance update synchronization with the accounts.txt file, and password-verified operations.
"""

import os  # Enables file operations like checking if a file exists or writing to it.
from utils import pause, slow_print, loading  # Imports utility functions for printing slowly, pausing,
# and simulating a loading animation.
from Authentication import ACCOUNTS_FILE  # Imports the path to the accounts.txt file from the authentication module.

def get_balance(username: str) -> float:  # Returns the current balance of a user by reading from accounts.txt.
    """
       Retrieves the wallet balance for a specific user.

       :param username: The username of the account to retrieve the balance from.
       :return: The balance as a float, or 0.00 if user not found.
       """
    with open(ACCOUNTS_FILE, "r") as file:  # Opens the file in read mode.
        for line in file:  # Loops through each line in the file.
            if not line.strip():  # Skips empty lines.
                continue
            name, _, _, balance = line.strip().split(",")  # Splits the line into username, email, password,
            # and balance.
            if name == username:  # If the username matches, return the balance.
                return float(balance)  # Converts the balance to float before returning.
    return 0.0  # If the user is not found, return 0 as the default balance.

def update_balance(username: str, new_balance: float) -> None:  # Updates the balance of a specific user in the accounts
    # file.
    lines = []  # Prepares a list to hold all updated lines.
    with open(ACCOUNTS_FILE, "r") as file:  # Opens the file to read all lines.
        for line in file:
            if not line.strip():  # Skips empty lines.
                continue
            name, email, password, balance = line.strip().split(",")  # Extracts user details from each line.
            if name == username:  # If the line belongs to the user, replace it with updated balance.
                lines.append(f"{name},{email},{password},{new_balance:.2f}\n")  # Formats and appends the new line.
            else:
                lines.append(line)  # Otherwise, keep the line unchanged.
    with open(ACCOUNTS_FILE, "w") as file:  # Opens the file in write mode to overwrite it.
        file.writelines(lines)  # Writes the updated lines back to the file.


def fund_wallet(username: str) -> None:  # Allows users to add funds to their wallet using predefined amounts.
    """
          Retrieves the current balance for the specified user from the accounts.txt file.

          :param username: The username whose balance is to be retrieved.
          :return: The user's current wallet balance as a float.
          """
    slow_print("--- Fund Wallet ---")  # Prints title with typing effect.
    print("Select an amount to fund your wallet:")
    options = [10000, 20000, 50000, 100000]  # Predefined funding options.
    for idx, amount in enumerate(options, 1):  # Displays options with indices.
        print(f"{idx}. NGN {amount}")
    try:
        choice = int(input("Enter choice (1-4): "))  # Takes user input as an integer.
        if choice < 1 or choice > len(options):  # Validates the choice range.
            raise ValueError  # Raises error if choice is invalid.
        amount_to_add = options[choice - 1]  # Gets the corresponding amount from the list.
        current_balance = get_balance(username)  # Retrieves the current balance.
        new_balance = current_balance + amount_to_add  # Adds the chosen amount to the balance.
        update_balance(username, new_balance)  # Updates the balance in the file.
        loading("Funding wallet")  # Simulates a loading effect.
        slow_print(f"Successfully added NGN {amount_to_add} to your wallet.")  # Confirms success.
        pause()  # Pauses so user can read the message.
    except ValueError:  # Catches errors if input was not a valid number.
        slow_print("Invalid selection. Please enter a number from 1 to 4.")  # Prints error message.
        pause()  # Waits for user before continuing.

def deduct_wallet(username: str, amount: float) -> bool:
    """
       Deducts a specified amount from a user's wallet if sufficient funds exist.

       :param username: The username of the account to deduct from.
       :param amount: The amount to deduct.
       :return: True if deduction is successful, False if insufficient funds.
       """
    current_balance = get_balance(username)  # Gets the current wallet balance.
    if current_balance >= amount:  # Checks if there is enough balance.
        update_balance(username, current_balance - amount)  # Deducts the amount and updates the file.
        return True  # Returns True to indicate successful deduction.
    return False  # Returns False if funds are insufficient.

def reset_balance(username: str) -> None:  # Resets a user’s balance to zero after verifying their password.
    """
       Resets a user's wallet balance to zero after verifying their password.

       :param username: The username of the account to reset.
       :return: None
       """
    from Authentication import sign_in  # Imports sign_in function to re-authenticate user.
    slow_print("Password verification required to reset balance.")  # Alerts the user for verification.
    user = sign_in()  # Calls sign_in for re-authentication.
    if user == username:  # If the user matches the logged-in username.
        update_balance(username, 0.00)  # Sets balance to 0.
        loading("Resetting balance")  # Simulates a reset animation.
        slow_print("Balance reset to NGN 0.00")  # Confirms reset success.
        pause()  # Pauses for user to read the message.
    else:
        slow_print("Password verification failed. Cannot reset balance.")  # If verification fails.
        pause()  # Pause to let the user read the failure message.
