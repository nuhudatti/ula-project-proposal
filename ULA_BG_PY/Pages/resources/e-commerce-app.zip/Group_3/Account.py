from Authentication import  ACCOUNTS_FILE
from utils import (
    user_data,
    load_users,
    save_users,
    confirm_password_strength,
    password_generator,
    slow_print,
    pause,
    clear_screen
)

def manage_account(current_user) -> str|None:
    """
    Displays the account management menu for the current user.

    :param current_user: The logged-in username
    :return: Updated username if changed, or the same username
    """
    load_users(ACCOUNTS_FILE)

    while True:
        clear_screen()
        slow_print("\n==== Manage Account ===")
        print("1. Change username")
        print("2. Change email")
        print("3. Change password")
        print("4. View account details")
        print("5. Reset Balance")
        print("6. Delete account")
        print("7. Logout")
        print("8. Exit")

        choice = input("Select option (1-8): ").strip()

        if choice in ['1', '2', '3', '5', '6']:
            password = input("Enter your current password: ").strip()
            if password != user_data[current_user]['password']:
                slow_print("Incorrect password.\n")
                pause()
                continue

        if choice == '1':
            new_username = input("Enter new username: ").strip()
            if not new_username:
                slow_print("Username cannot be empty.")
                pause()
                continue
            if new_username in user_data:
                slow_print("Username already exists!\n")
                pause()
                continue
            user_data[new_username] = user_data.pop(current_user)
            current_user = new_username
            save_users(ACCOUNTS_FILE)
            slow_print("Username updated successfully!\n")
            pause()
            return current_user  # Return new username

        elif choice == '2':
            new_email = input("Enter new email: ").strip()
            if not new_email:
                slow_print("Email cannot be empty.")
                pause()
                continue
            if any(data['email'] == new_email for data in user_data.values()):
                slow_print("Email already exists!\n")
                pause()
                continue
            user_data[current_user]['email'] = new_email
            save_users(ACCOUNTS_FILE)
            slow_print("Email updated successfully!\n")
            pause()

        elif choice == '3':
            slow_print("1. Manual password entry")
            slow_print("2. Auto-generate password")
            pass_choice = input("Choose option (1-2): ").strip()
            if pass_choice == '1':
                new_password = input("Enter new password: ").strip()
                if not confirm_password_strength(new_password):
                    slow_print("Password does not meet requirements!")
                    pause()
                    continue
            elif pass_choice == '2':
                new_password = password_generator()
                slow_print(f"Generated password: {new_password}")
            else:
                slow_print("Invalid choice.")
                pause()
                continue
            user_data[current_user]['password'] = new_password
            save_users(ACCOUNTS_FILE)
            slow_print("Password updated successfully!\n")
            pause()

        elif choice == '4':
            slow_print("\nAccount Details:")
            slow_print(f"Username: {current_user}")
            slow_print(f"Email: {user_data[current_user]['email']}")
            slow_print(f"Balance: NGN {user_data[current_user]['balance']:,.2f}")
            pause()

        elif choice == '5':
            confirm = input("Are you sure you want to reset your balance? (yes/no): ").strip().lower()
            if confirm == 'yes':
                user_data[current_user]['balance'] = 0.0
                save_users(ACCOUNTS_FILE)
                slow_print("Balance reset to NGN 0.00\n")
            else:
                slow_print("Balance reset cancelled.")
            pause()

        elif choice == '6':
            confirm = input("Are you sure you want to delete your account? (yes/no): ").strip().lower()
            if confirm == 'yes':
                del user_data[current_user]
                save_users(ACCOUNTS_FILE)
                slow_print("🗑Account deleted successfully.\n")
                pause()
                return None  # Deleted user — should log out
            else:
                slow_print("Account deletion cancelled.")
                pause()

        elif choice == '7':
            slow_print(f"Goodbye, {current_user}! Thanks for shopping with us.")
            pause()
            return current_user  # Log out — unchanged

        elif choice == '8':
            break

        else:
            slow_print("Invalid option. Try again.")
            pause()

    return current_user





