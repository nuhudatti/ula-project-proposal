# Band Name Generator
print("Welcome to the Band Name Generator!")

first_name = input("Enter Your Fist Name ")
last_name = input("Enter Your Last Name  ")

full_name = first_name + " " + last_name
print("You Full Name Is: " + full_name)
