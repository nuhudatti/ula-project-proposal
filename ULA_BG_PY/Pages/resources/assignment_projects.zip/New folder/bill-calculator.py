def calculate_tip(bill, tip_percentage):
    return bill * (tip_percentage / 100)

def calculate_total(bill, tip):
    return bill + tip

print("Welcome to the Tip Calculator!")

bill = float(input("What is the total bill? $"))
tip_percentage = float(input("What percentage tip would you like to give? "))

tip = calculate_tip(bill, tip_percentage)
total = calculate_total(bill, tip)

print(f"Your tip is: ${tip:.2f}")
print(f"Your total bill is: ${total:.2f}")
