def get_input():
    """Function to take and validate user input."""
    while True:
        try:
            user_input = input("Enter a number (or 'quit' to exit): ")
            if user_input.lower() == 'quit':
                return None
            num = float(user_input)
            return num
        except ValueError:
            print("Invalid input! Please enter a valid number.")

def perform_operation(state):
    """Function to perform an operation on the current state."""
    print(f"Current result: {state}")
    operation = input("Enter operation (+, -, *, /): ")
    if operation not in ['+', '-', '*', '/']:
        print("Invalid operation! Please choose one of: +, -, *, /")
        return state

    num = get_input()
    if num is None:
        return None

    if operation == '+':
        state += num
    elif operation == '-':
        state -= num
    elif operation == '*':
        state *= num
    elif operation == '/':
        if num == 0:
            print("Cannot divide by zero!")
            return state
        state /= num

    return state

def main():
    """Main function to run the calculator."""
    print("Welcome to the Advanced Calculator!")
    state = get_input()  # Initial state is set by the first number
    if state is None:
        return

    while True:
        state = perform_operation(state)
        if state is None:
            break
        print(f"Updated result: {state}")
        continue_prompt = input("Do you want to continue? (y/n): ").lower()
        if continue_prompt != 'y':
            break

    print("Thanks for using the calculator!")

if __name__ == "__main__":
    main()
