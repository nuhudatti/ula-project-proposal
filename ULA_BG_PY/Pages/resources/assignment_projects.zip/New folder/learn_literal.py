# print()


# literal and varialble

# varialble rule
# 1. no symbols
# 2. dont start variable with number

# naming convention
# snake = python, rust
# camalCase = everything js/c++
# PascalCase = struct, class, interface and enums
# CONSTAMT_CASE = conversion of constant python rust
# _snake_case = use on python, avoid it

# builins
# print

# search on
# sys.stdount
# stdin, stdout,stderr

# argument by position when passing to a print
# 1.argument pass to parameter
# 2.parameter

# when you use * all argument go to simglr paramiter like on print

# print()
# sep in print default =" " can set to ""
# end in print dealt = /n breake line

# input()
 # always add space for input
 #  input function always retuent a string i.e -> str

 # type()
 # to return a data type
 # syntex errow can be datatype
 # python ignore data type except when adding


 # f string
# name = input("Enter your name")
# print(f"welxcome to python {name}") similar to javascript as backticks `
# print(f"welxcome to python {name =}")

# arithmetic
# + - / * %

