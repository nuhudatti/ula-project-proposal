import random

# List of possible choices
choices = ["rock", "paper", "scissors"]

# Function to determine the winner
def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return "It's a tie!"
    elif user_choice == "rock":
        return "You win!" if computer_choice == "scissors" else "You lose!"
    elif user_choice == "paper":
        return "You win!" if computer_choice == "rock" else "You lose!"
    elif user_choice == "scissors":
        return "You win!" if computer_choice == "paper" else "You lose!"

# Game loop
while True:
    # Get user's choice
    user_choice = input("Enter rock, paper, or scissors (or 'quit' to end): ").lower()
    if user_choice == 'quit':
        print("Thanks for playing!")
        break

    if user_choice not in choices:
        print("Invalid choice. Please try again.")
        continue

    # Computer's choice
    computer_choice = random.choice(choices)
    print(f"Computer chooses: {computer_choice}")

    # Determine the winner
    result = determine_winner(user_choice, computer_choice)
    print(result)
