# square_area.py
side = float(input("Enter the length of the square's side: "))
area = side ** 2
print(f"The area of the square is {area:.2f} square units.")
