# pentagon_area.py
import math
side = float(input("Enter the side length of the regular pentagon: "))
area = (1/4) * math.sqrt(5 * (5 + 2 * math.sqrt(5))) * side ** 2
print(f"The area of the regular pentagon is {area:.2f} square units.")
