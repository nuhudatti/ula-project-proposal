# trapezium_area.py
a = float(input("Enter the length of the first parallel side (a): "))
b = float(input("Enter the length of the second parallel side (b): "))
h = float(input("Enter the height of the trapezium: "))
area = 0.5 * (a + b) * h
print(f"The area of the trapezium is {area:.2f} square units.")
