ini_var = [1, 2, 3]
print(f"{ini_var = }")
ini_var_tuple = (1, 2, 3)
print(f"{ini_var_tuple}")
ini_var_tuple = (1, 2)
print(f"{ini_var_tuple = }")

tuple1 = (1, 2, 3, 4, [5, 6], 7, 8, "9")
a, b, c, d, f_list, g, h, i_str = tuple1

print(f"{a = }")
print(f"{b = }")
print(f"{f_list = }")
print(f"{i_str = }")
print("\n\n")

a, b, *c = tuple1
print(f"{a = }")
print(f"{b = }")
print(f"{c = }")
print("\n\n")

a, b, c, d, e, f, g, h = tuple1
print(f"{a = }")
print(f"{b = }")
print(f"{c = }")
print("\n\n")

a, *b = tuple1
print(f"{a = }")
print(f"{b = }")
print(f"{c = }")

int("1.23a")