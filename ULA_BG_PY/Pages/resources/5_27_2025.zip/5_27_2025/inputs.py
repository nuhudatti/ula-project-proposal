# a function that returns a string from the user
def read_str(prompt: str) -> str:
    user_input: str = input(prompt)
    user_input = user_input.strip()
    return user_input

# a function that returns an integer from the user
def read_int(prompt: str) -> int | None:
    user_input: str = read_str(prompt)
    # try-catch
    # try-except
    # try:
    #   day 1 of church activities
    #   camera on. On the watchout
    #   Pastor A sneaks into the treasury, collects urgent 500k
    # catch (Money laundry)
    #   recover the money its more important
    #   beat the animal live
    #   hand over the thief to the police.
    try:
        value: int = int(user_input)
        return value
    except ValueError:
        return None

# a function that returns a float from the user
def read_float(prompt: str) -> float | None:
    user_input: str = read_str(prompt)
    # try-catch
    # try-except
    # try:
    #   day 1 of church activities
    #   camera on. On the watchout
    #   Pastor A sneaks into the treasury, collects urgent 500k
    # catch (Money laundry)
    #   recover the money its more important
    #   beat the animal live
    #   hand over the thief to the police.
    try:
        value: float = float(user_input)
        return value
    except ValueError:
        return None