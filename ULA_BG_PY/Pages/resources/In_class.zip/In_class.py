"""
Study Material: Python Basics - Loops, Conditions, and Strings

This script demonstrates:
1. Looping through a list of fruits to find those starting with a capital 'P'.
2. Extracting a substring from a word and converting it to uppercase.
3. Basic use of a `for` loop with a counter.
4. Filtering list elements based on their starting character.
5. Usage of the `range()` function.
6. Implementing FizzBuzz using conditionals and loops.
7. A simple `while` loop simulation.
"""

# 1. Loop through the list of fruits and print only the ones that start with a capital 'P'
fruits: list[str] = ["Banana", "peach", "Strawberry", "Orange", "Agbalumo", "Paw-paw", "Pineapple"]
print("Fruits that start with capital 'P':")
for fruit in fruits:
    if fruit.startswith("P"):
        print(fruit)

print("\n" + "-" * 30)

# 2. Extract and print "an" from "Orange" in uppercase
word = "Orange"
substring = word[2:4].upper()  # "an" from "Orange"
print(f"Substring from 'Orange' in uppercase: {substring}")

print("\n" + "-" * 30)

# 3. Basic loop with a counter
num = 0
for dish in ["jollof rice", "suya"]:
    print("Jason")
    num += 1
print(f"Total dishes: {num}")

print("\n" + "-" * 30)

# 4. Print fruits that start with a lowercase 'p'
print("Fruits that start with lowercase 'p':")
for fruit in fruits:
    if fruit.startswith("p"):
        print(fruit)

print("\n" + "-" * 30)

# 5. FizzBuzz: Loop from 1 to 100 with special print rules
print("FizzBuzz from 1 to 100:")
for num in range(1, 101):
    if num % 3 == 0 and num % 5 == 0:
        print(f"{num}: Fizz-Buzz")
    elif num % 3 == 0:
        print(f"{num}: Fizz")
    elif num % 5 == 0:
        print(f"{num}: Buzz")
    else:
        print(num)

print("\n" + "-" * 30)

# 6. While loop example: Water level simulation
print("Water level simulation with while loop:")
water_lvl = 0
while water_lvl < 5:
    print(f"{water_lvl}: Keep Tap On")
    water_lvl += 1
    print(f"New water level: {water_lvl}")
