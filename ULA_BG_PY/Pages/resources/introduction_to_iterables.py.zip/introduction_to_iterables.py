"""
Prelude: Introduction to Iterable Data Types

Before diving into `for` loops, it’s essential to understand what it means to "iterate" and
which data types in Python support iteration.

In this tutorial, students will learn:
1. The meaning of "iterate" and "iteration".
2. Why some types (e.g., integers, floats) are not iterable.
3. How the `range()` function makes it possible to iterate over sequences of numbers.
4. Hands-on examples with Nigerian-flavored analogies to cement concepts.

"""

# 1. What Does "Iterate" Mean?
"""
To "iterate" means to "go over" or "repeat" an action for each item in a collection, one at a time.
When you iterate, you take one element, do something with it, then move to the next.
"""
# Example with a list of suya spices (manual access):
spices: list[str] = ["pepp er", "garlic", "ginger"]
# We access each element by index to illustrate iteration:
print(f"Step 1: Add {spices[0]} to the suya mix.")  # pepper
print(f"Step 2: Add {spices[1]} to the suya mix.")  # garlic
print(f"Step 3: Add {spices[2]} to the suya mix.")  # ginger
num = 3142
# This sequence of accesses (0, 1, 2) shows what loops automate for you.

# 2. Iterable Data Types
"""
An *iterable* is any object that can return its elements one at a time.
Once a type is iterable, you can use loops (like `for`) to process every element.
Common iterable types include:
  - list    (e.g., meals at a Nigerian party)
  - tuple   (e.g., fixed prices)
  - string  (e.g., words or greetings)
  - dict    (iterates over keys by default)
  - set     (unique collection of items)
  - range   (sequence of numbers)

# Below is a preview of how you'd loop—
# but don’t worry if the `for` syntax is new; we’ll dive into that next.

# Example preview (won’t run yet):
# for dish in ["jollof rice", "suya"]:
#     print(dish)
"""

# 3. Why Integers and Floats Are Not Iterable
"""
Types like `int` and `float` represent single values, not collections of items.
They have no elements to "go over", so Python cannot iterate them directly.
"""
# If you tried to loop over an int, you’d get an error:
# >>> for num in 5:
# ...     print(num)
# TypeError: 'int' object is not iterable

# The same applies to floats:
# >>> for f in 3.14:
# ...     print(f)
# TypeError: 'float' object is not iterable

# Once you understand this, the `range()` function lets you build a collection of numbers to iterate.

# 4. Introducing the range() Function
"""
The built-in `range()` generates an iterable sequence of integers, allowing you to iterate over numbers.
Syntax:
  - range(stop)
  - range(start, stop)
  - range(start, stop, step)

# Preview of using range with a loop:
# for i in range(5):
#     print(i)  # would print 0,1,2,3,4

Nigerian analogy: Harvesting plantains in bunches of 3
# You have 12 plantains; to pick every 3rd one:
# for pick in range(3, 13, 3):
#     print(pick)  # picks 3,6,9,12
"""

# 5. Real-World Analogy
"""
Imagine a vegetable seller lining up crates:
- Iterable: the line of crates (you can go crate by crate)
- Non-iterable: each individual carrot inside unless you list them
- `range()`: stamping numbers on crates so you can loop over crate numbers once loops are introduced.
"""

# 6. Summary
"""
- **Iterate/Iteration**: Process items one at a time from a collection.
- **Iterable**: Objects you can loop over (list, string, tuple, dict, set, range).
- **Non-iterable**: Single-value types (int, float) have no items.
- **range()**: Creates number sequences that become iterable.

Next up: mastering `for` loops to harness these iterables!
"""
