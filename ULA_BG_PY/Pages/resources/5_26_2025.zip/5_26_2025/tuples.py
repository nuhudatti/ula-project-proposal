opps_list: list[str] = [
    "Anele Gold",
    "Onouha Raphael",
    "Adejoh Caleb"
]

# account = (username, password)
# username = input("Enter your username: ")
# password = input("Enter your password: ")
# account = (username, password)

artist_info: tuple[str, float] = ("Drake", 790e6)

hit_list: tuple[str, ...] = ("Ini", "Abiola", "John Odey")
songs = [
    ("Billie Eilish", "Everything I wanted"),
    ("G.Eazy and Bebe Rexha", "Me, Myself and I")
]

first_victim = hit_list[0]
print(f"{first_victim = }")
print(f"{len(hit_list) = }")

artist_record: tuple[str, str, int, str, str] = ("Post Malone", "Circles", 49, "Austin Post", "Grew up somewhere with something that went wrong and a couple of ladies that broke his heart.")

artist_name, iconic_song, age, full_name, background = artist_record




