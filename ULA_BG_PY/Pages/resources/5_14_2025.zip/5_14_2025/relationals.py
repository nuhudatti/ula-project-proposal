num1 = 250
num2 = 2e3
# greater than (2 * e ^ 3)
print("\ngreater than")
cond: bool = num1 > num2
print(f"{cond = }")
# less than
print("\nless than")
cond = num1 < num2
print(f"{cond = }")
# greater than or equal to
print("\ngreater than or equal to")
cond = num1 >= num2
print(f"{cond = }")
# less than or equal to
print("\nless than or equal to")
cond = num1 <= num2
print(f"{cond = }")

# Work with most data types
# not equal to
print("\nnot equal to")
cond = num1 != num2
print(f"{cond = }")
# equal to
print("\nequal to")
cond = num1 == num2
print(f"{cond = }")

statement = "Lexi goes to school"
statement2 = "Lexi goes to play"
print("\nequal to")
cond = statement == statement2
print(f"{cond = }")

print("\nnot equal to")
cond = statement != statement2
print(f"{cond = }")