

# if True:
#   do something
# else:
#   do another thing

replies_with_a_word: bool = False
bills_on_first_chat: bool = False
can_cook: bool = False
has_goals_and_vision = False

if replies_with_a_word or bills_on_first_chat :
    print("Run away, you and your life-savings are endangered species")
else:
    if can_cook and has_goals_and_vision:
        print("She might actually be worth the trouble")


if replies_with_a_word or bills_on_first_chat:
    print("run away run away, what are you still doing run away!!!")
elif can_cook and not has_goals_and_vision:
    print("Keep her as the third wife")
elif not can_cook and has_goals_and_vision:
    print("Keep the conversation normal and watch and pray.")
elif can_cook and has_goals_and_vision:
    print("She is a wife material")
else:
    print("WE PLAY!!!")


# if "Ini":
#     print("We play")
# else:
#     print("Comma.")


