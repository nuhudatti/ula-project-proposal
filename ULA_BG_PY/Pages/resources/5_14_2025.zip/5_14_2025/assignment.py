# calculate the area and perimeter of a triangle

# base, height ; base = side
# area = 0.5 * base * height
# perimeter = 3 * base
print("This is a Triangle Calculator Program")
base = input("Enter the base of a triangle: ")
height: str = input("Enter the height of a triangle: ")
base_float: float = float(base)
height_float: float = float(height)
area = (1/2) * base_float * height_float
perimeter = 3 * base_float
print(f"The perimeter of the triangle = {perimeter}")
print(f"The area of the triangle = {area}")

# Data type conversion
# float
# float(value) -> value as float

# int
# int(value) -> value as int

# str
# str(value) -> value as str

# bool
# bool(value) -> value as bool