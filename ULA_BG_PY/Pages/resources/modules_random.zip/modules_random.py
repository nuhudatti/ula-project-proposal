"""
STUDY MATERIAL: Python Modules & the Random Module

WHAT IS A MODULE?
------------------
A module in Python is simply a file containing Python code (functions, variables, classes) that can be reused in other programs.
Python comes with many built-in modules like `math`, `random`, `datetime`, etc.

WHY USE MODULES?
------------------
- To organize your code better.
- To reuse code across different projects.
- To make your programs neater and easier to manage.

HOW TO IMPORT A MODULE:
-------------------------
You use the `import` keyword.

Examples:
    import random
    import math
    from random import randint

CREATING YOUR OWN MODULE:
--------------------------
1. Create a file named `my_module.py`
2. Write your functions or variables inside it:

    Example - my_module.py:
        def greet(name):
            return f"Hello, {name}!"

3. In another Python file, import it like this:

    from my_module import greet
    print(greet("Bamidele"))

------------------------------
LET'S EXPLORE THE RANDOM MODULE
------------------------------
The `random` module is used to generate random numbers or make random choices.
"""

import random  # Importing the built-in random module

print("1. Generate a random float between 0 and 1:")
print(random.random())  # e.g. 0.6394267984578837

print("\n2. Generate a random integer between two numbers:")
print(random.randint(1, 10))  # e.g. 7

print("\n3. Generate a random number from a range with step:")
print(random.randrange(0, 100, 5))  # e.g. 35 (any multiple of 5 between 0 and 95)

print("\n4. Choose a random item from a list:")
fruits: list[str] = ["Banana", "Peach", "Strawberry", "Orange", "Agbalumo", "Paw-paw", "Pineapple"]
print(random.choice(fruits))

print("\n5. Choose multiple unique random items from a list:")
print(random.sample(fruits, 3))  # e.g. ['Peach', 'Orange', 'Pineapple']

print("\n6. Shuffle a list randomly:")
random.shuffle(fruits)
print("Shuffled fruits:", fruits)

print("\n7. Random float within a specific range (e.g., 5.5 to 10.5):")
print(random.uniform(5.5, 10.5))

print("\n8. Simulating a dice roll:")
dice: int = random.randint(1, 6)
print(f"You rolled a {dice}")

print("\n9. Simulating a coin toss:")
coin: list[str] = random.choice(["Heads", "Tails"])
print(f"The coin shows: {coin}")

print("\n10. Password Generator Example:")
import string
characters = string.ascii_letters + string.digits + string.punctuation
password = ''.join(random.choices(characters, k=10))
print(f"Generated password: {password}")

"""
EXTRA: What if you want to repeat the same random output?

Use random.seed(number) to set the starting point for the random number generator.
This helps you get the same results every time (useful for debugging or teaching).

Example:
random.seed(42)
print(random.randint(1, 10))  # Will always give the same result when seed is 42
"""
