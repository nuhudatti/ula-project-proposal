print()

# literals and variables
age = 25
gist = "Did you know that Muneer stole Abdul's babe and when Abdul found out, he slapped Muneer so hard two teeth went out"
emanuel_passed_waec = False
lanre_balance = 3_000_000_000.0


# variable naming rules
# 1. Do not include symbols or spaces in your variable name except _
# 2. Do not start your variable with a number

@name = "Joshua"
name-friend = "Not your guy"
2name = "epic fail"


# variable naming conventions
his_name = "Dr. Mercy" # snake case (Python, Rust, R)
hisName = "Dr. Mercy" # camel case (virtually every other programming language)
HisName = "Dr. Mercy" # Pascal case (structs, classes, interfaces, and enums)
HIS_NAME = "Dr. Mercy" # constant case (this is the convention for naming constants)

# warning
_his_name = "Dr. Mercy" # use snake case but you start with '_'





