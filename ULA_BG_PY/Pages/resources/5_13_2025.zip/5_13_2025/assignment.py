# This calculates the area of a square
# Enter the length of the square: 7.5
# The perimeter of the square is 15.000000.
# The area of the square is 56.250000

# Please do this in the Python Programming language.

# Make this work with a
# i. Square
# ii. Circle
# iii. Parallelogram
# iv. Rectangle
# v. Triangle
# vi. Pentagon
# vii. Trapezium
#
# Assume that all the shapes are regular.
# Please ensure that all number printouts are to two decimal places.