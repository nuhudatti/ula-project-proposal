# A function is any block of code that performs a specific task


# PRINT
# when writing functions in python, we write
# FUNC_NAME() => the parentheses signify that you wish to execute that function.
print("I am hungry")
print(25)
print(35)
print(45.0)
print(True)

# Getting a function's manual.
print("I am going to ensure", "that Muneer gets his revenge")


maths_score = input("David please enter Muneer's true maths score: ")
print("After all the lies we get Muneer's real maths score", maths_score)
print(f"After all the lies we get Muneer's real maths_score {maths_score}")


score_type = type(maths_score)
print(score_type)