


inis_account = 700_000
muneer_transfer = 300_000
new_inis_account = inis_account + muneer_transfer
print(f"{new_inis_account = }")

muneer_age_on_paper = 25
muneer_age = muneer_age_on_paper * 2
print(f"Muneer is {muneer_age = } years of age. Muneer is long overdue for marriage")

num1 = 50
num2 = 30
result = num1 - num2
print(f"{result = }")

result = num1 / num2
print(f"{result = }")

land_len = 3_500_000
land_area = land_len ** 2
print(f"Al-ameen has a land of {land_area} sq metres.")




