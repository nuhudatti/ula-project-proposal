"""
Python For Loops - Beginners Guide

This tutorial covers everything a Python beginner in Nigeria needs to know about `for` loops.
We use type annotations, Uncle Joe–style f-strings, and Nigerian analogies (suya, jollof rice, akara) to make learning fun.

Sections:
1. What is a for loop?
2. Basic syntax
3. Using range()
4. Iterating over lists
5. Iterating over strings
6. Nested loops
7. Control flow: break & continue
8. Complete example

"""

# 1. What is a for loop?
"""
A `for` loop in Python lets you go through each item in an iterable (list, string, tuple, dict, set, range)
and run the same block of code for each item, one by one.
"""

# 2. Basic syntax
"""
for <loop_var> in <iterable>:
    # code block that runs for each item in the iterable
"""
# Example:
numbers: range = range(3)  # will generate 0, 1, 2
for i in numbers:
    print(f"Loop index: {i}")  # Uncle Joe–style f-string


# 3. Using range()
"""
Use `range(stop)`, `range(start, stop)`, or `range(start, stop, step)` to loop over a sequence of numbers.
"""
# Print numbers from 1 to 5
for n in range(1, 6):
    print(f"Number: {n}")


# 4. Iterating over lists
"""
Imagine listing popular Nigerian dishes sold at a party.
"""
foods: list[str] = ["jollof rice", "suya", "moin moin", "akara"]
for food in foods:
    print(f"Food item: {food}")


# 5. Iterating over strings
"""
Strings are also iterable: you can loop through each character.
Example: spelling out 'akara'.
"""
word: str = "akara"
for letter in word:
    print(f"Letter: {letter}")


# 6. Nested loops
"""
Loop inside a loop. Example: pair soups with swallows.
"""
soups: list[str]    = ["egusi", "ogbono"]
swallows: list[str] = ["eba", "fufu"]
for soup in soups:
    for swallow in swallows:
        print(f"Enjoy {soup} with {swallow}!")


# 7. Control flow: break & continue
"""
- `break` stops the loop immediately.
- `continue` skips to the next iteration.
"""
# Find 'suya' and stop
for item in foods:
    if item == "suya":
        print("Found suya! Time to feast.")
        break
    print(f"Checking {item}...")

# Skip 'akara' when printing
for item in foods:
    if item == "akara":
        continue
    print(f"Yum, {item}!")


# 8. Complete example
"""
Pair dish names with prices, skip expensive ones, and display the rest.
"""
dish_names: list[str]  = ["jollof rice", "suya", "ofe nsala", "pepper soup"]
prices: list[float]    = [200.0, 150.0, 300.0, 180.0]  # in Naira

for idx in range(len(dish_names)):
    name: str   = dish_names[idx]
    cost: float = prices[idx]
    if cost > 250.0:
        # too pricey
        print(f"Skipping {name} at ₦{cost}, way too expensive!")
        continue
    print(f"Dish {idx + 1}: {name} costs just ₦{cost} - pocket friendly!")

# End of tutorial
print("\nCongratulations! You've mastered Python for loops.")
